
import React, { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/components/ui/use-toast";
import { MessageSquare, ThumbsUp, Star, TrendingUp } from "lucide-react";

const OpinionesPage = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    nombre: "",
    email: "",
    tipo: "",
    tema: "",
    opinion: "",
    calificacion: "",
    anonimo: false
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activeTab, setActiveTab] = useState("compartir");

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === "checkbox" ? checked : value
    });
  };

  const handleSelectChange = (name, value) => {
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulando envío al servidor
    setTimeout(() => {
      // Guardar en localStorage
      const opinions = JSON.parse(localStorage.getItem("opinions") || "[]");
      const newOpinion = {
        id: Date.now(),
        ...formData,
        fechaCreacion: new Date().toISOString()
      };
      opinions.push(newOpinion);
      localStorage.setItem("opinions", JSON.stringify(opinions));
      
      setIsSubmitting(false);
      toast({
        title: "Opinión enviada",
        description: "Tu opinión ha sido registrada con éxito. Gracias por compartir tu perspectiva.",
        variant: "default",
      });
      
      // Resetear formulario
      setFormData({
        nombre: "",
        email: "",
        tipo: "",
        tema: "",
        opinion: "",
        calificacion: "",
        anonimo: false
      });
    }, 1500);
  };

  // Obtener opiniones del localStorage para mostrar
  const getOpinions = () => {
    const opinions = JSON.parse(localStorage.getItem("opinions") || "[]");
    return opinions.filter(opinion => !opinion.anonimo).slice(0, 6); // Mostrar solo las no anónimas
  };

  const opinions = getOpinions();

  return (
    <div className="container mx-auto px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="max-w-4xl mx-auto"
      >
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold mb-4">Opiniones Estudiantiles</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Tu voz es importante para nosotros. Comparte tus ideas, sugerencias y experiencias para ayudarnos a mejorar constantemente.
          </p>
        </div>

        <Tabs defaultValue="compartir" className="mb-10" onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="compartir" className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4" />
              Compartir opinión
            </TabsTrigger>
            <TabsTrigger value="ver" className="flex items-center gap-2">
              <ThumbsUp className="h-4 w-4" />
              Ver opiniones
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="compartir">
            <Card className="shadow-lg border-t-4 border-t-blue-600">
              <CardHeader>
                <CardTitle>Comparte tu opinión</CardTitle>
                <CardDescription>
                  Tus comentarios nos ayudan a mejorar nuestra comunidad educativa.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="nombre">Nombre completo</Label>
                        <Input
                          id="nombre"
                          name="nombre"
                          placeholder="Escribe tu nombre completo"
                          value={formData.nombre}
                          onChange={handleChange}
                          disabled={formData.anonimo}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email">Correo electrónico</Label>
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          placeholder="tu@correo.com"
                          value={formData.email}
                          onChange={handleChange}
                          disabled={formData.anonimo}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="tipo">Tipo de opinión *</Label>
                        <Select 
                          onValueChange={(value) => handleSelectChange("tipo", value)}
                          value={formData.tipo}
                          required
                        >
                          <SelectTrigger id="tipo">
                            <SelectValue placeholder="Selecciona el tipo" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="sugerencia">Sugerencia</SelectItem>
                            <SelectItem value="felicitacion">Felicitación</SelectItem>
                            <SelectItem value="queja">Queja</SelectItem>
                            <SelectItem value="idea">Idea de mejora</SelectItem>
                            <SelectItem value="otro">Otro</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="tema">Tema *</Label>
                        <Select 
                          onValueChange={(value) => handleSelectChange("tema", value)}
                          value={formData.tema}
                          required
                        >
                          <SelectTrigger id="tema">
                            <SelectValue placeholder="Selecciona el tema" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="academico">Académico</SelectItem>
                            <SelectItem value="infraestructura">Infraestructura</SelectItem>
                            <SelectItem value="convivencia">Convivencia escolar</SelectItem>
                            <SelectItem value="actividades">Actividades extracurriculares</SelectItem>
                            <SelectItem value="servicios">Servicios escolares</SelectItem>
                            <SelectItem value="profesores">Profesores</SelectItem>
                            <SelectItem value="administrativo">Personal administrativo</SelectItem>
                            <SelectItem value="otro">Otro</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="opinion">Tu opinión *</Label>
                      <Textarea
                        id="opinion"
                        name="opinion"
                        placeholder="Comparte tus ideas, sugerencias o experiencias..."
                        rows={5}
                        required
                        value={formData.opinion}
                        onChange={handleChange}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="calificacion">¿Cómo calificarías tu experiencia general en la institución? *</Label>
                      <Select 
                        onValueChange={(value) => handleSelectChange("calificacion", value)}
                        value={formData.calificacion}
                        required
                      >
                        <SelectTrigger id="calificacion">
                          <SelectValue placeholder="Selecciona una calificación" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="5">Excelente (5 estrellas)</SelectItem>
                          <SelectItem value="4">Muy buena (4 estrellas)</SelectItem>
                          <SelectItem value="3">Buena (3 estrellas)</SelectItem>
                          <SelectItem value="2">Regular (2 estrellas)</SelectItem>
                          <SelectItem value="1">Mala (1 estrella)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="anonimo"
                        name="anonimo"
                        className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                        checked={formData.anonimo}
                        onChange={handleChange}
                      />
                      <Label htmlFor="anonimo" className="text-sm font-normal">
                        Quiero compartir esta opinión de forma anónima
                      </Label>
                    </div>
                  </div>

                  <Button type="submit" className="w-full" disabled={isSubmitting}>
                    {isSubmitting ? "Enviando..." : "Enviar opinión"}
                  </Button>
                </form>
              </CardContent>
              <CardFooter className="flex flex-col items-start border-t pt-6">
                <p className="text-sm text-muted-foreground">
                  Tus opiniones son confidenciales y serán utilizadas únicamente para mejorar nuestros servicios educativos.
                </p>
              </CardFooter>
            </Card>
          </TabsContent>
          
          <TabsContent value="ver">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-blue-600" />
                    Opiniones de la comunidad
                  </CardTitle>
                  <CardDescription>
                    Conoce lo que otros miembros de nuestra comunidad educativa han compartido.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {opinions.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {opinions.map((opinion) => (
                        <motion.div
                          key={opinion.id}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.3 }}
                          className="bg-gray-50 p-4 rounded-lg border"
                        >
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <h4 className="font-medium">{opinion.nombre}</h4>
                              <p className="text-sm text-gray-500">
                                {new Date(opinion.fechaCreacion).toLocaleDateString()}
                              </p>
                            </div>
                            <div className="flex items-center">
                              {[...Array(parseInt(opinion.calificacion))].map((_, i) => (
                                <Star key={i} className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                              ))}
                            </div>
                          </div>
                          <div className="mb-2">
                            <span className="inline-block px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800 mr-2">
                              {opinion.tema === "academico" ? "Académico" : 
                               opinion.tema === "infraestructura" ? "Infraestructura" :
                               opinion.tema === "convivencia" ? "Convivencia escolar" :
                               opinion.tema === "actividades" ? "Actividades extracurriculares" :
                               opinion.tema === "servicios" ? "Servicios escolares" :
                               opinion.tema === "profesores" ? "Profesores" :
                               opinion.tema === "administrativo" ? "Personal administrativo" : "Otro"}
                            </span>
                            <span className="inline-block px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800">
                              {opinion.tipo === "sugerencia" ? "Sugerencia" : 
                               opinion.tipo === "felicitacion" ? "Felicitación" :
                               opinion.tipo === "queja" ? "Queja" :
                               opinion.tipo === "idea" ? "Idea de mejora" : "Otro"}
                            </span>
                          </div>
                          <p className="text-gray-700">{opinion.opinion}</p>
                        </motion.div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-10">
                      <p className="text-gray-500 mb-4">Aún no hay opiniones compartidas públicamente.</p>
                      <Button onClick={() => setActiveTab("compartir")} variant="outline">
                        Sé el primero en compartir tu opinión
                      </Button>
                    </div>
                  )}
                </CardContent>
                {opinions.length > 0 && (
                  <CardFooter className="border-t pt-6">
                    <p className="text-sm text-muted-foreground">
                      Solo se muestran las opiniones compartidas de forma no anónima. Respetamos la privacidad de todos los miembros de nuestra comunidad.
                    </p>
                  </CardFooter>
                )}
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </motion.div>
    </div>
  );
};

export default OpinionesPage;
