
import React, { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { useToast } from "@/components/ui/use-toast";
import { AlertTriangle, CheckCircle, Info, User, Calendar, MapPin } from "lucide-react";

const ReportePage = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    nombre: "",
    grado: "",
    grupo: "",
    fecha: "",
    lugar: "",
    tipoIncidente: "",
    descripcion: "",
    involucrados: "",
    testigos: "",
    anonimo: false
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === "checkbox" ? checked : value
    });
  };

  const handleSelectChange = (name, value) => {
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulando envío al servidor
    setTimeout(() => {
      // Guardar en localStorage
      const reports = JSON.parse(localStorage.getItem("reports") || "[]");
      const newReport = {
        id: Date.now(),
        ...formData,
        estado: "pendiente",
        fechaCreacion: new Date().toISOString()
      };
      reports.push(newReport);
      localStorage.setItem("reports", JSON.stringify(reports));
      
      setIsSubmitting(false);
      toast({
        title: "Reporte enviado",
        description: "Tu reporte ha sido enviado con éxito. Gracias por contribuir a un mejor ambiente escolar.",
        variant: "default",
      });
      
      // Resetear formulario
      setFormData({
        nombre: "",
        grado: "",
        grupo: "",
        fecha: "",
        lugar: "",
        tipoIncidente: "",
        descripcion: "",
        involucrados: "",
        testigos: "",
        anonimo: false
      });
    }, 1500);
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="max-w-4xl mx-auto"
      >
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold mb-4">Reportar Incidente</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Utiliza este formulario para reportar situaciones de bullying o faltas de respeto. 
            Todos los reportes son tratados con confidencialidad.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
          <Card className="bg-blue-50 border-blue-200">
            <CardHeader className="pb-2">
              <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center mb-2">
                <Info className="h-5 w-5 text-blue-600" />
              </div>
              <CardTitle className="text-blue-700">Confidencialidad</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-blue-700">
                Tu identidad será protegida. También puedes enviar reportes anónimos.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-green-50 border-green-200">
            <CardHeader className="pb-2">
              <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center mb-2">
                <CheckCircle className="h-5 w-5 text-green-600" />
              </div>
              <CardTitle className="text-green-700">Seguimiento</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-green-700">
                Cada reporte recibe atención y seguimiento por parte de nuestro equipo.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-amber-50 border-amber-200">
            <CardHeader className="pb-2">
              <div className="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center mb-2">
                <AlertTriangle className="h-5 w-5 text-amber-600" />
              </div>
              <CardTitle className="text-amber-700">Importante</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-amber-700">
                Proporciona información precisa para que podamos actuar adecuadamente.
              </p>
            </CardContent>
          </Card>
        </div>

        <Card className="shadow-lg border-t-4 border-t-blue-600">
          <CardHeader>
            <CardTitle>Formulario de Reporte</CardTitle>
            <CardDescription>
              Completa la información solicitada. Los campos marcados con * son obligatorios.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="nombre" className="flex items-center gap-2">
                      <User size={16} />
                      Nombre completo
                    </Label>
                    <Input
                      id="nombre"
                      name="nombre"
                      placeholder="Escribe tu nombre completo"
                      value={formData.nombre}
                      onChange={handleChange}
                      disabled={formData.anonimo}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="grado">Grado</Label>
                      <Select 
                        onValueChange={(value) => handleSelectChange("grado", value)}
                        value={formData.grado}
                      >
                        <SelectTrigger id="grado">
                          <SelectValue placeholder="Seleccionar" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1°</SelectItem>
                          <SelectItem value="2">2°</SelectItem>
                          <SelectItem value="3">3°</SelectItem>
                          <SelectItem value="4">4°</SelectItem>
                          <SelectItem value="5">5°</SelectItem>
                          <SelectItem value="6">6°</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="grupo">Grupo</Label>
                      <Select 
                        onValueChange={(value) => handleSelectChange("grupo", value)}
                        value={formData.grupo}
                      >
                        <SelectTrigger id="grupo">
                          <SelectValue placeholder="Seleccionar" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="A">A</SelectItem>
                          <SelectItem value="B">B</SelectItem>
                          <SelectItem value="C">C</SelectItem>
                          <SelectItem value="D">D</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="fecha" className="flex items-center gap-2">
                      <Calendar size={16} />
                      Fecha del incidente *
                    </Label>
                    <Input
                      id="fecha"
                      name="fecha"
                      type="date"
                      required
                      value={formData.fecha}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lugar" className="flex items-center gap-2">
                      <MapPin size={16} />
                      Lugar del incidente *
                    </Label>
                    <Input
                      id="lugar"
                      name="lugar"
                      placeholder="Ej. Patio, aula 203, baños..."
                      required
                      value={formData.lugar}
                      onChange={handleChange}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="tipoIncidente">Tipo de incidente *</Label>
                  <Select 
                    onValueChange={(value) => handleSelectChange("tipoIncidente", value)}
                    value={formData.tipoIncidente}
                    required
                  >
                    <SelectTrigger id="tipoIncidente">
                      <SelectValue placeholder="Selecciona el tipo de incidente" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="bullying_fisico">Bullying físico</SelectItem>
                      <SelectItem value="bullying_verbal">Bullying verbal</SelectItem>
                      <SelectItem value="bullying_social">Bullying social/exclusión</SelectItem>
                      <SelectItem value="bullying_cibernetico">Cyberbullying</SelectItem>
                      <SelectItem value="discriminacion">Discriminación</SelectItem>
                      <SelectItem value="acoso">Acoso</SelectItem>
                      <SelectItem value="vandalismo">Vandalismo</SelectItem>
                      <SelectItem value="otro">Otro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="descripcion">Descripción del incidente *</Label>
                  <Textarea
                    id="descripcion"
                    name="descripcion"
                    placeholder="Describe con detalle lo que ocurrió..."
                    rows={5}
                    required
                    value={formData.descripcion}
                    onChange={handleChange}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="involucrados">Personas involucradas *</Label>
                  <Textarea
                    id="involucrados"
                    name="involucrados"
                    placeholder="Nombres de las personas involucradas en el incidente..."
                    rows={3}
                    required
                    value={formData.involucrados}
                    onChange={handleChange}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="testigos">Testigos (si los hay)</Label>
                  <Textarea
                    id="testigos"
                    name="testigos"
                    placeholder="Nombres de personas que presenciaron el incidente..."
                    rows={3}
                    value={formData.testigos}
                    onChange={handleChange}
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="anonimo"
                    name="anonimo"
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    checked={formData.anonimo}
                    onChange={handleChange}
                  />
                  <Label htmlFor="anonimo" className="text-sm font-normal">
                    Quiero hacer este reporte de forma anónima
                  </Label>
                </div>
              </div>

              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button type="button" className="w-full" disabled={isSubmitting}>
                    {isSubmitting ? "Enviando..." : "Enviar reporte"}
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Confirmar envío de reporte</AlertDialogTitle>
                    <AlertDialogDescription>
                      ¿Estás seguro de que deseas enviar este reporte? Una vez enviado, no podrás modificarlo.
                      <br /><br />
                      La información proporcionada será tratada con confidencialidad y será utilizada únicamente para dar seguimiento al caso reportado.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                    <AlertDialogAction onClick={handleSubmit}>
                      Confirmar envío
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </form>
          </CardContent>
          <CardFooter className="flex flex-col items-start border-t pt-6">
            <p className="text-sm text-muted-foreground">
              Si estás en una situación de emergencia o peligro inmediato, por favor acude directamente a la dirección escolar o contacta al número de emergencias.
            </p>
          </CardFooter>
        </Card>
      </motion.div>
    </div>
  );
};

export default ReportePage;
