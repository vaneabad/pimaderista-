import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertTriangle, MessageSquare } from "lucide-react";
import DashboardStatsCards from "@/components/dashboard/DashboardStatsCards";
import ReportsTab from "@/components/dashboard/ReportsTab";
import OpinionsTab from "@/components/dashboard/OpinionsTab";
import AdminActions from "@/components/dashboard/AdminActions";

const DashboardPage = () => {
  const [reports, setReports] = useState([]);
  const [opinions, setOpinions] = useState([]);
  const [reportStats, setReportStats] = useState({
    total: 0,
    pending: 0,
    inProgress: 0,
    resolved: 0,
    byType: {}
  });
  const [opinionStats, setOpinionStats] = useState({
    total: 0,
    averageRating: 0,
    byType: {},
    byTopic: {}
  });

  useEffect(() => {
    const storedReports = JSON.parse(localStorage.getItem("reports") || "[]");
    setReports(storedReports);
    
    const pending = storedReports.filter(r => r.estado === "pendiente").length;
    const inProgress = storedReports.filter(r => r.estado === "en_proceso").length;
    const resolved = storedReports.filter(r => r.estado === "resuelto").length;
    
    const byType = storedReports.reduce((acc, report) => {
      acc[report.tipoIncidente] = (acc[report.tipoIncidente] || 0) + 1;
      return acc;
    }, {});
    
    setReportStats({
      total: storedReports.length,
      pending,
      inProgress,
      resolved,
      byType
    });
    
    const storedOpinions = JSON.parse(localStorage.getItem("opinions") || "[]");
    setOpinions(storedOpinions);
    
    const totalRating = storedOpinions.reduce((sum, op) => sum + parseInt(op.calificacion || "0"), 0);
    const avgRating = storedOpinions.length ? (totalRating / storedOpinions.length).toFixed(1) : "0.0";
    
    const byOpinionType = storedOpinions.reduce((acc, opinion) => {
      acc[opinion.tipo] = (acc[opinion.tipo] || 0) + 1;
      return acc;
    }, {});
    
    const byTopic = storedOpinions.reduce((acc, opinion) => {
      acc[opinion.tema] = (acc[opinion.tema] || 0) + 1;
      return acc;
    }, {});
    
    setOpinionStats({
      total: storedOpinions.length,
      averageRating: avgRating,
      byType: byOpinionType,
      byTopic
    });
  }, []);

  return (
    <div className="container mx-auto px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold mb-4">Dashboard Administrativo</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Monitoreo y análisis de reportes de bullying y opiniones estudiantiles.
          </p>
        </div>

        <DashboardStatsCards reportStats={reportStats} opinionStats={opinionStats} />

        <Tabs defaultValue="reportes" className="mb-10">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="reportes" className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4" />
              Reportes de Bullying
            </TabsTrigger>
            <TabsTrigger value="opiniones" className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4" />
              Opiniones Estudiantiles
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="reportes">
            <ReportsTab reports={reports} reportStats={reportStats} />
          </TabsContent>
          
          <TabsContent value="opiniones">
            <OpinionsTab opinions={opinions} opinionStats={opinionStats} />
          </TabsContent>
        </Tabs>

        <AdminActions />
      </motion.div>
    </div>
  );
};

export default DashboardPage;