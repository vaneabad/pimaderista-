
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { motion } from "framer-motion";
import { AlertTriangle, MessageSquare, BookOpen, Shield } from "lucide-react";

const HomePage = () => {
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="hero-gradient text-white py-20">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <motion.div 
              className="md:w-1/2 mb-10 md:mb-0"
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                Construyendo un ambiente escolar seguro y respetuoso
              </h1>
              <p className="text-lg mb-8">
                En el Instituto Mexicano Madero valoramos tu bienestar y tu voz. Juntos podemos crear un entorno educativo positivo para todos.
              </p>
              <div className="flex flex-wrap gap-4">
                <Button asChild size="lg" className="bg-white text-blue-700 hover:bg-gray-100">
                  <Link to="/reportar">Reportar incidente</Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="border-white text-white hover:bg-blue-800">
                  <Link to="/opiniones">Compartir opinión</Link>
                </Button>
              </div>
            </motion.div>
            <motion.div 
              className="md:w-1/2"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8 }}
            >
              <div className="rounded-lg overflow-hidden shadow-2xl">
                <img  alt="Estudiantes del Instituto Mexicano Madero en un ambiente educativo positivo" className="w-full h-auto" src="https://images.unsplash.com/photo-1701701046353-89f1a671c24b" />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl font-bold mb-4">¿Cómo podemos ayudarte?</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Nuestra plataforma ofrece herramientas para reportar incidentes, compartir opiniones y acceder a recursos útiles.
            </p>
          </motion.div>

          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
            variants={container}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true }}
          >
            <motion.div variants={item}>
              <Card className="h-full card-hover">
                <CardHeader>
                  <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center mb-4">
                    <AlertTriangle className="h-6 w-6 text-red-500" />
                  </div>
                  <CardTitle>Reportar Bullying</CardTitle>
                  <CardDescription>
                    Informa de manera segura y confidencial situaciones de acoso escolar.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    Todos los reportes son tratados con seriedad y confidencialidad para garantizar tu seguridad.
                  </p>
                </CardContent>
                <CardFooter>
                  <Button asChild variant="outline" className="w-full">
                    <Link to="/reportar">Hacer reporte</Link>
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>

            <motion.div variants={item}>
              <Card className="h-full card-hover">
                <CardHeader>
                  <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                    <MessageSquare className="h-6 w-6 text-blue-500" />
                  </div>
                  <CardTitle>Compartir Opiniones</CardTitle>
                  <CardDescription>
                    Tu voz es importante para mejorar nuestra comunidad educativa.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    Comparte tus ideas, sugerencias y experiencias para ayudarnos a mejorar constantemente.
                  </p>
                </CardContent>
                <CardFooter>
                  <Button asChild variant="outline" className="w-full">
                    <Link to="/opiniones">Dar opinión</Link>
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>

            <motion.div variants={item}>
              <Card className="h-full card-hover">
                <CardHeader>
                  <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mb-4">
                    <BookOpen className="h-6 w-6 text-green-500" />
                  </div>
                  <CardTitle>Recursos Educativos</CardTitle>
                  <CardDescription>
                    Accede a materiales sobre convivencia, respeto y bienestar emocional.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    Encuentra guías, artículos y herramientas para fomentar un ambiente escolar positivo.
                  </p>
                </CardContent>
                <CardFooter>
                  <Button asChild variant="outline" className="w-full">
                    <Link to="/recursos">Ver recursos</Link>
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>

            <motion.div variants={item}>
              <Card className="h-full card-hover">
                <CardHeader>
                  <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center mb-4">
                    <Shield className="h-6 w-6 text-purple-500" />
                  </div>
                  <CardTitle>Política Institucional</CardTitle>
                  <CardDescription>
                    Conoce nuestras políticas contra el acoso y faltas de respeto.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    Estamos comprometidos con mantener un entorno seguro y respetuoso para toda nuestra comunidad.
                  </p>
                </CardContent>
                <CardFooter>
                  <Button asChild variant="outline" className="w-full">
                    <Link to="/recursos">Leer políticas</Link>
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl font-bold mb-4">Nuestra Comunidad</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Conoce las experiencias de estudiantes, profesores y padres de familia que forman parte de nuestra institución.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="bg-white p-6 rounded-lg shadow-md"
            >
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full overflow-hidden mr-4">
                  <img  alt="Foto de perfil de estudiante" className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1609560553121-c25d93a3df51" />
                </div>
                <div>
                  <h4 className="font-semibold">Carlos Mendoza</h4>
                  <p className="text-sm text-gray-600">Estudiante, 3er año</p>
                </div>
              </div>
              <p className="text-gray-700 italic">
                "Gracias a la plataforma de reportes, pude informar una situación difícil que estaba enfrentando. La respuesta fue rápida y me sentí apoyado en todo momento."
              </p>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="bg-white p-6 rounded-lg shadow-md"
            >
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full overflow-hidden mr-4">
                  <img  alt="Foto de perfil de profesora" className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1646315449332-f1246af4feba" />
                </div>
                <div>
                  <h4 className="font-semibold">Mtra. Laura Jiménez</h4>
                  <p className="text-sm text-gray-600">Profesora de Ciencias</p>
                </div>
              </div>
              <p className="text-gray-700 italic">
                "Como docente, valoro mucho esta herramienta que nos permite estar más conectados con las necesidades de nuestros estudiantes y actuar oportunamente."
              </p>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="bg-white p-6 rounded-lg shadow-md"
            >
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full overflow-hidden mr-4">
                  <img  alt="Foto de perfil de padre de familia" className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1535643302794-19c3804b874b" />
                </div>
                <div>
                  <h4 className="font-semibold">Roberto Vázquez</h4>
                  <p className="text-sm text-gray-600">Padre de familia</p>
                </div>
              </div>
              <p className="text-gray-700 italic">
                "Me da tranquilidad saber que la escuela cuenta con mecanismos efectivos para atender situaciones de bullying y que mi hijo tiene un espacio seguro para expresarse."
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl font-bold mb-4">¿Listo para contribuir a un mejor ambiente escolar?</h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto">
              Tu participación es fundamental para construir una comunidad educativa basada en el respeto y la colaboración.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button asChild size="lg" className="bg-white text-blue-700 hover:bg-gray-100">
                <Link to="/reportar">Reportar incidente</Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="border-white text-white hover:bg-blue-700">
                <Link to="/opiniones">Compartir opinión</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
