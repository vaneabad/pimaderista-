
import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { BookOpen, FileText, Video, Download, ExternalLink, Shield, Heart, Users } from "lucide-react";

const RecursosPage = () => {
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="max-w-5xl mx-auto"
      >
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold mb-4">Recursos Educativos</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Encuentra materiales útiles sobre convivencia escolar, prevención del bullying y bienestar emocional.
          </p>
        </div>

        <Tabs defaultValue="materiales" className="mb-10">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="materiales" className="flex items-center gap-2">
              <BookOpen className="h-4 w-4" />
              Materiales Educativos
            </TabsTrigger>
            <TabsTrigger value="politicas" className="flex items-center gap-2">
              <Shield className="h-4 w-4" />
              Políticas Institucionales
            </TabsTrigger>
            <TabsTrigger value="bienestar" className="flex items-center gap-2">
              <Heart className="h-4 w-4" />
              Bienestar Emocional
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="materiales">
            <Card>
              <CardHeader>
                <CardTitle>Materiales Educativos</CardTitle>
                <CardDescription>
                  Recursos para estudiantes, docentes y padres de familia sobre prevención del bullying y promoción de la convivencia escolar.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <motion.div 
                  className="grid grid-cols-1 md:grid-cols-2 gap-6"
                  variants={container}
                  initial="hidden"
                  animate="show"
                >
                  <motion.div variants={item} className="bg-white border rounded-lg overflow-hidden shadow-sm">
                    <div className="aspect-video relative overflow-hidden bg-gray-100">
                      <img  alt="Guía para estudiantes sobre prevención del bullying" className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1553870982-966ef13c4d54" />
                    </div>
                    <div className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <FileText className="h-4 w-4 text-blue-600" />
                        <span className="text-sm font-medium text-blue-600">Guía PDF</span>
                      </div>
                      <h3 className="font-semibold mb-2">Guía para Estudiantes: Prevención del Bullying</h3>
                      <p className="text-sm text-gray-600 mb-4">
                        Material educativo con estrategias para identificar, prevenir y actuar frente a situaciones de acoso escolar.
                      </p>
                      <Button variant="outline" size="sm" className="w-full flex items-center gap-2">
                        <Download className="h-4 w-4" />
                        Descargar guía
                      </Button>
                    </div>
                  </motion.div>

                  <motion.div variants={item} className="bg-white border rounded-lg overflow-hidden shadow-sm">
                    <div className="aspect-video relative overflow-hidden bg-gray-100">
                      <img  alt="Video tutorial sobre resolución de conflictos" className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1574738102321-f8b42792a5f0" />
                    </div>
                    <div className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Video className="h-4 w-4 text-blue-600" />
                        <span className="text-sm font-medium text-blue-600">Video</span>
                      </div>
                      <h3 className="font-semibold mb-2">Resolución de Conflictos en el Aula</h3>
                      <p className="text-sm text-gray-600 mb-4">
                        Video tutorial con técnicas prácticas para resolver conflictos de manera pacífica y constructiva.
                      </p>
                      <Button variant="outline" size="sm" className="w-full flex items-center gap-2">
                        <ExternalLink className="h-4 w-4" />
                        Ver video
                      </Button>
                    </div>
                  </motion.div>

                  <motion.div variants={item} className="bg-white border rounded-lg overflow-hidden shadow-sm">
                    <div className="aspect-video relative overflow-hidden bg-gray-100">
                      <img  alt="Infografía sobre comunicación asertiva" className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1567485898576-90fd71a80b0a" />
                    </div>
                    <div className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <FileText className="h-4 w-4 text-blue-600" />
                        <span className="text-sm font-medium text-blue-600">Infografía</span>
                      </div>
                      <h3 className="font-semibold mb-2">Comunicación Asertiva para Adolescentes</h3>
                      <p className="text-sm text-gray-600 mb-4">
                        Infografía con consejos prácticos para mejorar la comunicación y expresar opiniones de manera respetuosa.
                      </p>
                      <Button variant="outline" size="sm" className="w-full flex items-center gap-2">
                        <Download className="h-4 w-4" />
                        Descargar infografía
                      </Button>
                    </div>
                  </motion.div>

                  <motion.div variants={item} className="bg-white border rounded-lg overflow-hidden shadow-sm">
                    <div className="aspect-video relative overflow-hidden bg-gray-100">
                      <img  alt="Guía para padres sobre ciberbullying" className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1701701046353-89f1a671c24b" />
                    </div>
                    <div className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <FileText className="h-4 w-4 text-blue-600" />
                        <span className="text-sm font-medium text-blue-600">Guía PDF</span>
                      </div>
                      <h3 className="font-semibold mb-2">Guía para Padres: Prevención del Ciberbullying</h3>
                      <p className="text-sm text-gray-600 mb-4">
                        Material informativo para padres sobre cómo identificar y prevenir el acoso en entornos digitales.
                      </p>
                      <Button variant="outline" size="sm" className="w-full flex items-center gap-2">
                        <Download className="h-4 w-4" />
                        Descargar guía
                      </Button>
                    </div>
                  </motion.div>
                </motion.div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="politicas">
            <Card>
              <CardHeader>
                <CardTitle>Políticas Institucionales</CardTitle>
                <CardDescription>
                  Documentos oficiales del Instituto Mexicano Madero sobre convivencia escolar y protocolos de actuación.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <motion.div 
                  className="space-y-6"
                  variants={container}
                  initial="hidden"
                  animate="show"
                >
                  <motion.div variants={item} className="bg-blue-50 border border-blue-100 rounded-lg p-6">
                    <div className="flex items-start gap-4">
                      <div className="bg-white p-3 rounded-full shadow-sm">
                        <Shield className="h-6 w-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold mb-2">Política de Convivencia Escolar</h3>
                        <p className="text-gray-700 mb-4">
                          Este documento establece los principios, valores y normas que rigen la convivencia en nuestra institución, con el objetivo de promover un ambiente escolar seguro, respetuoso e inclusivo.
                        </p>
                        <div className="space-y-4">
                          <div className="bg-white p-4 rounded-md border border-gray-200">
                            <h4 className="font-medium mb-2">Contenido del documento:</h4>
                            <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
                              <li>Principios y valores institucionales</li>
                              <li>Derechos y responsabilidades de los estudiantes</li>
                              <li>Normas de convivencia en espacios comunes</li>
                              <li>Procedimientos para la resolución de conflictos</li>
                              <li>Medidas formativas y disciplinarias</li>
                              <li>Protocolos de actuación frente a situaciones específicas</li>
                            </ul>
                          </div>
                          <Button className="w-full sm:w-auto flex items-center gap-2">
                            <Download className="h-4 w-4" />
                            Descargar política completa
                          </Button>
                        </div>
                      </div>
                    </div>
                  </motion.div>

                  <motion.div variants={item} className="bg-green-50 border border-green-100 rounded-lg p-6">
                    <div className="flex items-start gap-4">
                      <div className="bg-white p-3 rounded-full shadow-sm">
                        <Users className="h-6 w-6 text-green-600" />
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold mb-2">Protocolo de Actuación frente al Bullying</h3>
                        <p className="text-gray-700 mb-4">
                          Este protocolo establece los procedimientos y medidas que se implementan en nuestra institución para prevenir, detectar y abordar situaciones de acoso escolar.
                        </p>
                        <div className="space-y-4">
                          <div className="bg-white p-4 rounded-md border border-gray-200">
                            <h4 className="font-medium mb-2">Etapas del protocolo:</h4>
                            <ol className="list-decimal list-inside text-sm text-gray-600 space-y-1">
                              <li>Detección y reporte de la situación</li>
                              <li>Evaluación preliminar y medidas de protección</li>
                              <li>Investigación del caso</li>
                              <li>Intervención con los involucrados</li>
                              <li>Seguimiento y evaluación de las medidas</li>
                              <li>Cierre del proceso</li>
                            </ol>
                          </div>
                          <Button className="w-full sm:w-auto flex items-center gap-2">
                            <Download className="h-4 w-4" />
                            Descargar protocolo completo
                          </Button>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                </motion.div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="bienestar">
            <Card>
              <CardHeader>
                <CardTitle>Bienestar Emocional</CardTitle>
                <CardDescription>
                  Recursos para promover la salud mental y el bienestar emocional de nuestra comunidad educativa.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-8">
                  <div className="relative rounded-xl overflow-hidden">
                    <img  alt="Estudiantes participando en actividades de bienestar emocional" className="w-full h-64 object-cover" src="https://images.unsplash.com/photo-1611170670010-d27907f26cbe" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                      <div className="p-6 text-white">
                        <h3 className="text-2xl font-bold mb-2">Programa de Bienestar Integral</h3>
                        <p className="text-white/90">
                          Iniciativas y actividades diseñadas para promover el bienestar emocional, físico y social de nuestra comunidad educativa.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <motion.div 
                  className="grid grid-cols-1 md:grid-cols-2 gap-6"
                  variants={container}
                  initial="hidden"
                  animate="show"
                >
                  <motion.div variants={item} className="bg-white border rounded-lg overflow-hidden shadow-sm">
                    <div className="p-5 border-b bg-purple-50">
                      <h3 className="font-semibold text-purple-800">Técnicas de Manejo del Estrés</h3>
                    </div>
                    <div className="p-5">
                      <p className="text-gray-600 mb-4">
                        Aprende técnicas prácticas para manejar el estrés académico y mantener un equilibrio emocional saludable.
                      </p>
                      <ul className="space-y-2 mb-4">
                        <li className="flex items-center gap-2 text-sm">
                          <div className="w-2 h-2 rounded-full bg-purple-500"></div>
                          <span>Ejercicios de respiración consciente</span>
                        </li>
                        <li className="flex items-center gap-2 text-sm">
                          <div className="w-2 h-2 rounded-full bg-purple-500"></div>
                          <span>Técnicas de relajación muscular</span>
                        </li>
                        <li className="flex items-center gap-2 text-sm">
                          <div className="w-2 h-2 rounded-full bg-purple-500"></div>
                          <span>Mindfulness para adolescentes</span>
                        </li>
                        <li className="flex items-center gap-2 text-sm">
                          <div className="w-2 h-2 rounded-full bg-purple-500"></div>
                          <span>Organización del tiempo y prioridades</span>
                        </li>
                      </ul>
                      <Button variant="outline" size="sm" className="w-full">Ver recursos</Button>
                    </div>
                  </motion.div>

                  <motion.div variants={item} className="bg-white border rounded-lg overflow-hidden shadow-sm">
                    <div className="p-5 border-b bg-blue-50">
                      <h3 className="font-semibold text-blue-800">Inteligencia Emocional</h3>
                    </div>
                    <div className="p-5">
                      <p className="text-gray-600 mb-4">
                        Desarrolla habilidades para reconocer y gestionar tus emociones, así como para comprender las de los demás.
                      </p>
                      <ul className="space-y-2 mb-4">
                        <li className="flex items-center gap-2 text-sm">
                          <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                          <span>Reconocimiento de emociones</span>
                        </li>
                        <li className="flex items-center gap-2 text-sm">
                          <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                          <span>Regulación emocional</span>
                        </li>
                        <li className="flex items-center gap-2 text-sm">
                          <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                          <span>Empatía y habilidades sociales</span>
                        </li>
                        <li className="flex items-center gap-2 text-sm">
                          <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                          <span>Comunicación asertiva</span>
                        </li>
                      </ul>
                      <Button variant="outline" size="sm" className="w-full">Ver recursos</Button>
                    </div>
                  </motion.div>

                  <motion.div variants={item} className="bg-white border rounded-lg overflow-hidden shadow-sm">
                    <div className="p-5 border-b bg-green-50">
                      <h3 className="font-semibold text-green-800">Hábitos Saludables</h3>
                    </div>
                    <div className="p-5">
                      <p className="text-gray-600 mb-4">
                        Información y consejos para mantener hábitos saludables que contribuyan a tu bienestar físico y mental.
                      </p>
                      <ul className="space-y-2 mb-4">
                        <li className="flex items-center gap-2 text-sm">
                          <div className="w-2 h-2 rounded-full bg-green-500"></div>
                          <span>Alimentación equilibrada</span>
                        </li>
                        <li className="flex items-center gap-2 text-sm">
                          <div className="w-2 h-2 rounded-full bg-green-500"></div>
                          <span>Actividad física regular</span>
                        </li>
                        <li className="flex items-center gap-2 text-sm">
                          <div className="w-2 h-2 rounded-full bg-green-500"></div>
                          <span>Higiene del sueño</span>
                        </li>
                        <li className="flex items-center gap-2 text-sm">
                          <div className="w-2 h-2 rounded-full bg-green-500"></div>
                          <span>Uso responsable de la tecnología</span>
                        </li>
                      </ul>
                      <Button variant="outline" size="sm" className="w-full">Ver recursos</Button>
                    </div>
                  </motion.div>

                  <motion.div variants={item} className="bg-white border rounded-lg overflow-hidden shadow-sm">
                    <div className="p-5 border-b bg-amber-50">
                      <h3 className="font-semibold text-amber-800">Apoyo Psicológico</h3>
                    </div>
                    <div className="p-5">
                      <p className="text-gray-600 mb-4">
                        Información sobre los servicios de apoyo psicológico disponibles en nuestra institución y cómo acceder a ellos.
                      </p>
                      <ul className="space-y-2 mb-4">
                        <li className="flex items-center gap-2 text-sm">
                          <div className="w-2 h-2 rounded-full bg-amber-500"></div>
                          <span>Consejería individual</span>
                        </li>
                        <li className="flex items-center gap-2 text-sm">
                          <div className="w-2 h-2 rounded-full bg-amber-500"></div>
                          <span>Talleres grupales</span>
                        </li>
                        <li className="flex items-center gap-2 text-sm">
                          <div className="w-2 h-2 rounded-full bg-amber-500"></div>
                          <span>Orientación vocacional</span>
                        </li>
                        <li className="flex items-center gap-2 text-sm">
                          <div className="w-2 h-2 rounded-full bg-amber-500"></div>
                          <span>Líneas de apoyo emocional</span>
                        </li>
                      </ul>
                      <Button variant="outline" size="sm" className="w-full">Ver recursos</Button>
                    </div>
                  </motion.div>
                </motion.div>
              </CardContent>
              <CardFooter className="border-t pt-6">
                <p className="text-sm text-muted-foreground">
                  Si necesitas apoyo emocional inmediato, no dudes en contactar al Departamento de Psicología de la institución o llamar a la línea de apoyo emocional al (222) 123-4567.
                </p>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </motion.div>
    </div>
  );
};

export default RecursosPage;
