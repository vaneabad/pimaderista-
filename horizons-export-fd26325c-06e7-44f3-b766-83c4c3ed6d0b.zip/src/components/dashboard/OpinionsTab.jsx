import React from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Filter } from "lucide-react";
import { getOpinionTypeName, getTopicName } from "@/lib/dashboardUtils";

const OpinionsTab = ({ opinions, opinionStats }) => {
  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Opiniones Estudiantiles</CardTitle>
            <CardDescription>
              Listado de opiniones y sugerencias recibidas.
            </CardDescription>
          </div>
          <Button variant="outline" size="sm" className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            Filtrar
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {opinions.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-50 text-left">
                  <th className="px-4 py-3 text-sm font-medium text-gray-500">ID</th>
                  <th className="px-4 py-3 text-sm font-medium text-gray-500">Fecha</th>
                  <th className="px-4 py-3 text-sm font-medium text-gray-500">Tipo</th>
                  <th className="px-4 py-3 text-sm font-medium text-gray-500">Tema</th>
                  <th className="px-4 py-3 text-sm font-medium text-gray-500">Calificación</th>
                  <th className="px-4 py-3 text-sm font-medium text-gray-500">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {opinions.map((opinion) => (
                  <tr key={opinion.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3 text-sm">{opinion.id.toString().slice(-4)}</td>
                    <td className="px-4 py-3 text-sm">{new Date(opinion.fechaCreacion).toLocaleDateString()}</td>
                    <td className="px-4 py-3 text-sm">{getOpinionTypeName(opinion.tipo)}</td>
                    <td className="px-4 py-3 text-sm">{getTopicName(opinion.tema)}</td>
                    <td className="px-4 py-3 text-sm">
                      <div className="flex items-center">
                        {[...Array(parseInt(opinion.calificacion || "0"))].map((_, i) => (
                          <svg key={i} className="w-4 h-4 text-yellow-500 fill-current" viewBox="0 0 24 24">
                            <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                          </svg>
                        ))}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm">
                      <Button variant="ghost" size="sm">Ver detalles</Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-10">
            <p className="text-gray-500">No hay opiniones registradas aún.</p>
          </div>
        )}
      </CardContent>
      {opinions.length > 0 && (
        <CardFooter className="border-t pt-6 flex justify-between">
          <p className="text-sm text-muted-foreground">
            Mostrando {opinions.length} opiniones en total
          </p>
          <div className="flex gap-2">
            <Button variant="outline" size="sm">Exportar datos</Button>
            <Button size="sm">Generar informe</Button>
          </div>
        </CardFooter>
      )}

      {opinions.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6 p-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Distribución por Tipo de Opinión</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Object.entries(opinionStats.byType).map(([type, count]) => (
                  <div key={type} className="flex items-center">
                    <div className="w-32 text-sm">{getOpinionTypeName(type)}</div>
                    <div className="flex-1">
                      <div className="h-4 bg-gray-100 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-green-500 rounded-full"
                          style={{ width: `${(count / opinionStats.total) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                    <div className="w-10 text-right text-sm font-medium">{count}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Distribución por Tema</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Object.entries(opinionStats.byTopic).map(([topic, count]) => (
                  <div key={topic} className="flex items-center">
                    <div className="w-32 text-sm">{getTopicName(topic)}</div>
                    <div className="flex-1">
                      <div className="h-4 bg-gray-100 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-purple-500 rounded-full"
                          style={{ width: `${(count / opinionStats.total) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                    <div className="w-10 text-right text-sm font-medium">{count}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </Card>
  );
};

export default OpinionsTab;