import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle, Clock, MessageSquare, BarChart } from "lucide-react";

const DashboardStatsCards = ({ reportStats, opinionStats }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
      <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
        <CardHeader className="pb-2">
          <CardTitle className="text-2xl font-bold text-blue-700">{reportStats.total}</CardTitle>
          <CardDescription className="text-blue-600">Total de reportes</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center">
            <AlertTriangle className="h-5 w-5 text-blue-600 mr-2" />
            <p className="text-blue-700 text-sm">
              Reportes de incidentes registrados
            </p>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-yellow-50 to-yellow-100 border-yellow-200">
        <CardHeader className="pb-2">
          <CardTitle className="text-2xl font-bold text-yellow-700">{reportStats.pending}</CardTitle>
          <CardDescription className="text-yellow-600">Reportes pendientes</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center">
            <Clock className="h-5 w-5 text-yellow-600 mr-2" />
            <p className="text-yellow-700 text-sm">
              Esperando revisión inicial
            </p>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
        <CardHeader className="pb-2">
          <CardTitle className="text-2xl font-bold text-green-700">{opinionStats.total}</CardTitle>
          <CardDescription className="text-green-600">Opiniones recibidas</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center">
            <MessageSquare className="h-5 w-5 text-green-600 mr-2" />
            <p className="text-green-700 text-sm">
              Comentarios y sugerencias
            </p>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
        <CardHeader className="pb-2">
          <CardTitle className="text-2xl font-bold text-purple-700">{opinionStats.averageRating}</CardTitle>
          <CardDescription className="text-purple-600">Calificación promedio</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center">
            <BarChart className="h-5 w-5 text-purple-600 mr-2" />
            <p className="text-purple-700 text-sm">
              Satisfacción general (1-5)
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DashboardStatsCards;