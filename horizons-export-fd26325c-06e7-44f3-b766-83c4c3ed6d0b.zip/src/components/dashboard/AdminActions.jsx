import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PieChart, BarChart, Filter } from "lucide-react";

const AdminActions = () => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Acciones Administrativas</CardTitle>
        <CardDescription>
          Herramientas para la gestión de reportes y opiniones.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Button className="w-full flex items-center justify-center gap-2 h-auto py-6">
            <div className="flex flex-col items-center">
              <PieChart className="h-6 w-6 mb-2" />
              <span>Generar Informe Completo</span>
            </div>
          </Button>
          <Button variant="outline" className="w-full flex items-center justify-center gap-2 h-auto py-6">
            <div className="flex flex-col items-center">
              <BarChart className="h-6 w-6 mb-2" />
              <span>Análisis de Tendencias</span>
            </div>
          </Button>
          <Button variant="secondary" className="w-full flex items-center justify-center gap-2 h-auto py-6">
            <div className="flex flex-col items-center">
              <Filter className="h-6 w-6 mb-2" />
              <span>Configurar Alertas</span>
            </div>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default AdminActions;