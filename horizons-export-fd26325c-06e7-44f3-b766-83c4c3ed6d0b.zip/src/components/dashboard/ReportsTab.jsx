import React from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Filter } from "lucide-react";
import { getStatusBadge, getIncidentTypeName } from "@/lib/dashboardUtils";

const ReportsTab = ({ reports, reportStats }) => {
  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Reportes de Bullying y Faltas de Respeto</CardTitle>
            <CardDescription>
              Listado de reportes recibidos y su estado actual.
            </CardDescription>
          </div>
          <Button variant="outline" size="sm" className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            Filtrar
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {reports.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-50 text-left">
                  <th className="px-4 py-3 text-sm font-medium text-gray-500">ID</th>
                  <th className="px-4 py-3 text-sm font-medium text-gray-500">Fecha</th>
                  <th className="px-4 py-3 text-sm font-medium text-gray-500">Tipo</th>
                  <th className="px-4 py-3 text-sm font-medium text-gray-500">Lugar</th>
                  <th className="px-4 py-3 text-sm font-medium text-gray-500">Estado</th>
                  <th className="px-4 py-3 text-sm font-medium text-gray-500">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {reports.map((report) => (
                  <tr key={report.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3 text-sm">{report.id.toString().slice(-4)}</td>
                    <td className="px-4 py-3 text-sm">{new Date(report.fechaCreacion).toLocaleDateString()}</td>
                    <td className="px-4 py-3 text-sm">{getIncidentTypeName(report.tipoIncidente)}</td>
                    <td className="px-4 py-3 text-sm">{report.lugar}</td>
                    <td className="px-4 py-3 text-sm">{getStatusBadge(report.estado)}</td>
                    <td className="px-4 py-3 text-sm">
                      <Button variant="ghost" size="sm">Ver detalles</Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-10">
            <p className="text-gray-500">No hay reportes registrados aún.</p>
          </div>
        )}
      </CardContent>
      {reports.length > 0 && (
        <CardFooter className="border-t pt-6 flex justify-between">
          <p className="text-sm text-muted-foreground">
            Mostrando {reports.length} reportes en total
          </p>
          <div className="flex gap-2">
            <Button variant="outline" size="sm">Exportar datos</Button>
            <Button size="sm">Generar informe</Button>
          </div>
        </CardFooter>
      )}

      {reports.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6 p-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Distribución por Tipo de Incidente</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Object.entries(reportStats.byType).map(([type, count]) => (
                  <div key={type} className="flex items-center">
                    <div className="w-32 text-sm">{getIncidentTypeName(type)}</div>
                    <div className="flex-1">
                      <div className="h-4 bg-gray-100 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-blue-500 rounded-full"
                          style={{ width: `${(count / reportStats.total) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                    <div className="w-10 text-right text-sm font-medium">{count}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Estado de los Reportes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center h-48">
                <div className="grid grid-cols-3 gap-4 w-full">
                  <div className="flex flex-col items-center justify-center p-4 bg-yellow-50 rounded-lg border border-yellow-100">
                    <div className="text-yellow-700 text-2xl font-bold mb-2">{reportStats.pending}</div>
                    <div className="text-yellow-600 text-sm text-center">Pendientes</div>
                  </div>
                  <div className="flex flex-col items-center justify-center p-4 bg-blue-50 rounded-lg border border-blue-100">
                    <div className="text-blue-700 text-2xl font-bold mb-2">{reportStats.inProgress}</div>
                    <div className="text-blue-600 text-sm text-center">En proceso</div>
                  </div>
                  <div className="flex flex-col items-center justify-center p-4 bg-green-50 rounded-lg border border-green-100">
                    <div className="text-green-700 text-2xl font-bold mb-2">{reportStats.resolved}</div>
                    <div className="text-green-600 text-sm text-center">Resueltos</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </Card>
  );
};

export default ReportsTab;